import 'package:flutter/material.dart';
import 'package:myfood/RaisedGradientButton.dart';
import 'package:myfood/rutas/detalle_producto.dart';

import 'Producto.dart';

class ListaProductos extends StatelessWidget {
  final List<Producto> products;
  ListaProductos(this.products);

  Widget _buildProductItem(BuildContext context, int index) {
    print(products[index].titulo);

    return Card(
        child: //Column(
            //children: <Widget>[
            Row(
      mainAxisAlignment: MainAxisAlignment.start,
      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(10),
          child: Image.asset(
            "imagenes/${products[index].foto}",
            height: 100,
          ),
        ),
        Flexible(
          // Para hacer que el texto quepa en la columna
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 5, bottom: 5, right: 5),
                child: Text(products[index].titulo,
                    softWrap: false,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 20.0,
                        color: const Color(0xffff0000),
                        fontWeight: FontWeight.w600,
                        fontFamily: "Roboto")),
              ),
              Text(
                products[index].texto,
                maxLines: 2,
                softWrap: false,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 14.0,
                    color: Colors.black87,
                    fontWeight: FontWeight.w600,
                    fontFamily: "Roboto"),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Text(
                  products[index].precio,
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 5),
                child: RaisedGradientButton(
                    height: 20,
                    width: 100,
                    child: Text("Ver"),
                    gradient: LinearGradient(
                      colors: <Color>[Colors.red, Colors.red[50]],
                    ),
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DetalleProductoPage()));
                    }),
              )
            ],
          ),
        )
      ],
    )
        //],
        //),
        );
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: _buildProductItem,
      itemCount: products.length,
    );
  }
}
