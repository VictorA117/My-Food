class Restaurante
{
  String foto;
  String titulo;
  String descripcion;
  List<String> fotosProductos;

  Restaurante(this.foto, this.titulo, this.descripcion, this.fotosProductos);
}