import 'package:flutter/material.dart';
import 'package:myfood/clases/Restaurante.dart';
import 'package:myfood/rutas/detalle_restaurante.dart';
import '../RaisedGradientButton.dart';

class ListaRestaurantes extends StatelessWidget {
  final List<Restaurante> restaurantes;
  ListaRestaurantes(this.restaurantes);

  Widget _buildRestauranteItem(BuildContext context, int index) {
    print(restaurantes[index].titulo);

    return Card(
      color: Colors.grey[200],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(10),
            child: Image.asset(
              "imagenes/${restaurantes[index].foto}",
            ),
          ),
          Padding(
              padding: const EdgeInsets.only(top: 5, bottom: 5),
              child: Center(
                child: Text(restaurantes[index].titulo,
                    softWrap: false,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 24.0,
                        color: const Color(0xffff0000),
                        fontWeight: FontWeight.w600,
                        fontFamily: "Roboto")),
              )),
          Padding(
            padding: const EdgeInsets.all(15),
            child: Text(
              restaurantes[index].descripcion,
              maxLines: 4,
              softWrap: false,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.black87,
                  fontWeight: FontWeight.w600,
                  fontFamily: "Roboto"),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 5, bottom: 15),
            child: Center(
                child: RaisedGradientButton(
                    height: 20,
                    width: 100,
                    child: Text("Ver"),
                    gradient: LinearGradient(
                      colors: <Color>[Colors.red, Colors.red[50]],
                    ),
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DetalleRestaurantePage()));
                    })),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: _buildRestauranteItem,
      itemCount: restaurantes.length,
    );
  }
}
