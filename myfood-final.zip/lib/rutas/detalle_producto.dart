import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:myfood/RaisedGradientButton.dart';
import 'package:myfood/clases/Producto.dart';
import 'package:myfood/clases/menu.dart';

class DetalleProductoPage extends StatefulWidget {
  DetalleProductoPage({Key key, String title}) : super(key: key);

  @override
  _DetalleProductoPage createState() => _DetalleProductoPage();
}

class _DetalleProductoPage extends State<DetalleProductoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text('MyFood - Producto'), actions: makeMenu(context)),
      body: SingleChildScrollView(
        child: FutureBuilder(
            builder: (context, snapshot) {
              List prods = jsonDecode(snapshot.data.toString());
              Producto producto = Producto(prods[0]["foto"], prods[0]["titulo"],
                  prods[0]["texto"], prods[0]["precio"]);

              return DetalleProducto(producto);
            },
            future: DefaultAssetBundle.of(context)
                .loadString("assets/productos.json")),
      ),
    );
  }
}

class DetalleProducto extends StatelessWidget {
  Producto producto;
  DetalleProducto(this.producto);

  @override
  Widget build(BuildContext context) {
    var numPedido = TextEditingController();

    numPedido.value = TextEditingValue(text: "1");

    return Column(
      children: <Widget>[
        Padding(
          padding: EdgeInsets.all(5),
          child: Image.asset("imagenes/${producto.foto}"),
        ),
        Card(
            color: Colors.grey[200],
            child: Column(children: <Widget>[
              Padding(
                padding: EdgeInsets.all(5),
                child: Text(producto.titulo,
                    softWrap: false,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 28.0,
                        color: const Color(0xffff0000),
                        fontWeight: FontWeight.w600,
                        fontFamily: "Roboto")),
              ),
              Padding(
                padding: EdgeInsets.all(5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text("Ahora por ",
                        style: TextStyle(
                            fontSize: 20.0,
                            color: const Color(0xff000000),
                            fontWeight: FontWeight.w600,
                            fontFamily: "Roboto")),
                    Text(producto.precio,
                        style: TextStyle(
                            fontSize: 24.0,
                            decoration: TextDecoration.underline,
                            color: const Color(0xff000000),
                            fontWeight: FontWeight.w600,
                            fontFamily: "Roboto")),
                  ],
                ),
              ),
              Padding(
                  padding: EdgeInsets.all(15),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(producto.texto,
                        textAlign: TextAlign.justify,
                        style: TextStyle(
                            fontSize: 14.0,
                            color: const Color(0xff000000),
                            fontFamily: "Roboto")),
                  )),
              Padding(
                padding: EdgeInsets.all(5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      "Quiero ",
                      style: TextStyle(fontSize: 25),
                    ),
                    Container(
                        width: 75,
                        child: Padding(
                            padding: EdgeInsets.only(left: 5),
                            child: TextField(
                              controller: numPedido,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              maxLength: 2,
                              style: TextStyle(fontSize: 20),
                            ))),
                    RaisedGradientButton(
                      padding: EdgeInsets.only(left: 10),
                      height: 30,
                      child: Text("Pedir"),
                      gradient: LinearGradient(
                        colors: <Color>[Colors.red, Colors.red[100]],
                      ),
                      borderRadius: 10,
                      onPressed: () {
                        mensajePedido(context);
                      },
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.all(5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Switch(
                      value: true,
                      onChanged: (changed) {},
                    ),
                    Text(
                      "Quiero la oferta especial!",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                    )
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.all(15),
                child: Text(
                  "Al realizar el pedido, el cliente deberá suministrar los datos de su tarjeta de crédito/débito, " +
                      "Siendo esta información gestionada por el banco y facturada inmediatamente. En caso de reclamación, por favor " +
                      "llamar al teléfono XXX-XXX-XXX en horario de oficina.",
                  style: TextStyle(fontSize: 11),
                ),
              )
            ])),
      ],
    );
  }

  Future<void> mensajePedido(BuildContext context) async {
    return showDialog<void>(
        context: context,
        barrierDismissible:
            false, // El usuario debe pulsar en el botón para salir
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("MyFood - Pedidos"),
            content: Text("¿Estás seguro de que quieres realizar el pedido?"),
            actions: <Widget>[
              FlatButton(
                child: Text(
                  "Sí",
                  style: TextStyle(fontSize: 20),
                ),
                onPressed: () {},
              ),
              FlatButton(
                child: Text("No"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              )
            ],
          );
        });
  }
}
