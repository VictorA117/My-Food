import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:myfood/clases/Producto.dart';
import 'package:myfood/clases/Productos.dart';
import 'package:myfood/clases/menu.dart';

class ListaProductosPage extends StatefulWidget {
  ListaProductosPage({Key key, String title}) : super(key: key);

  @override
  _ListaProductosPage createState() => _ListaProductosPage();
}

class _ListaProductosPage extends State<ListaProductosPage> {
  @override
  Widget build(BuildContext context) {
    var productos = List<Producto>();

    return Scaffold(
        appBar: AppBar(
            title: new Text('MyFood - Productos'), actions: makeMenu(context)),
        body: Column(children: [
          FutureBuilder(
            builder: (context, snapshot) {
              List rest = jsonDecode(snapshot.data.toString());
              for (var item in rest) {
                productos.add(Producto(item["foto"], item["titulo"],
                    item["texto"], item["precio"]));
              }

              return Flexible(child: ListaProductos(productos));
            },
            future: DefaultAssetBundle.of(context)
                .loadString("assets/productos.json"),
          )
          //Flexible(child: ListaProductos(productos))
        ]));
  }
}
