import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:myfood/RaisedGradientButton.dart';
import 'package:myfood/clases/menu.dart';

class PedidoPage extends StatefulWidget {
  PedidoPage({Key key, String title}) : super(key: key);

  @override
  _PedidoPage createState() => new _PedidoPage();
}

class _PedidoPage extends State<PedidoPage> {
  int selectedRecogida = -1;
  int selectedPago = -1;

  void onChangedRecogida(int value) => setState(() {
        selectedRecogida = value;
      });

  void onChangedPago(int value) => setState(() {
        selectedPago = value;
      });

  Widget makeDetallePedido(String titulo, int cantidad, String precio) {
    return Padding(
      child: Row(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Text("$cantidad x ",
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 20)),
          Text(
            "$titulo ($precio)",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
          FlatButton(
            child: Text(
              "Borrar",
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.w500),
            ),
            onPressed: () {},
          ),
        ],
      ),
      padding: EdgeInsets.all(0),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("MyFood - Pedido"),
          actions: makeMenu(context)
        ),
        body: Stack(
          children: <Widget>[
            Opacity(
              opacity: 0.25,
              child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("imagenes/fondo2.jpg"),
                      fit: BoxFit.cover,
                    ),
                    color: Colors.black.withAlpha(90)),
              ),
            ),
            SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      "Hoja de pedido",
                      style: new TextStyle(
                          fontSize: 30.0,
                          color: const Color(0xffff0000),
                          fontWeight: FontWeight.w600,
                          fontFamily: "Roboto"),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text("Estos son los platos que has solicitado:", style: TextStyle(fontWeight: FontWeight.w500),),
                  ),
                  Center(
                    child: Container(
                      padding:
                          const EdgeInsets.only(left: 15, right: 15, top: 5),
                      margin: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          border: Border.all(width: 1)),
                      child: Column(
                        children: <Widget>[
                          makeDetallePedido("Bocadillo de carne", 2, "19,95 €"),
                          Divider(
                            color: Colors.red,
                          ),
                          makeDetallePedido(
                              "Ensalada tres delicias", 1, "39,95 €"),
                          Divider(
                            color: Colors.red,
                          ),
                          makeDetallePedido("Plato de pita", 3, "69,95 €")
                        ],
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text("Total pedido:     ",
                          style: TextStyle(fontSize: 16)),
                      Text("289,70 €",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w600))
                    ],
                  ),
                  Padding(
                      child: Divider(color: Colors.red),
                      padding: const EdgeInsets.all(5)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Radio(
                          value: 0,
                          groupValue: selectedRecogida,
                          onChanged: onChangedRecogida),
                      Text("Envío a domicilio", style: TextStyle(fontWeight: FontWeight.w500)),
                      Radio(
                          value: 1,
                          groupValue: selectedRecogida,
                          onChanged: onChangedRecogida),
                      Text("Recoger en local", style: TextStyle(fontWeight: FontWeight.w500)),
                    ],
                  ),
                  Padding(
                      child: Divider(color: Colors.red),
                      padding: const EdgeInsets.all(5)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Radio(
                          value: 0,
                          groupValue: selectedPago,
                          onChanged: onChangedPago),
                      Text("Pago en la entrega", style: TextStyle(fontWeight: FontWeight.w500)),
                      Radio(
                          value: 1,
                          groupValue: selectedPago,
                          onChanged: onChangedPago),
                      Text("Pago con tarjeta", style: TextStyle(fontWeight: FontWeight.w500)),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Radio(
                          value: 2,
                          groupValue: selectedPago,
                          onChanged: onChangedPago),
                      Text("Pago con PayPal", style: TextStyle(fontWeight: FontWeight.w500))
                    ],
                  ),
                  Padding(
                      child: Divider(color: Colors.red),
                      padding: const EdgeInsets.all(5)),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: RaisedGradientButton(
                        width: 200,
                        child: Text(
                          'Realizar pedido',
                          style:
                              TextStyle(color: Colors.black87, fontSize: 20.0),
                        ),
                        gradient: LinearGradient(
                          colors: <Color>[Colors.red, Colors.red[100]],
                        ),
                        borderRadius: 10,
                        onPressed: () {}),
                  )
                ],
              ),
            ),
          ],
        ));
  }
}
