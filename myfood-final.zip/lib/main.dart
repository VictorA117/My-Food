import 'package:flutter/material.dart';
import 'rutas/login.dart';

void main() => runApp(MyFoodApp());

class MyFoodApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyFood App',
      theme: ThemeData(
primarySwatch: Colors.red,
        primaryColor: const Color(0xFFf44336),
        accentColor: const Color(0xFFf44336),
        canvasColor: const Color(0xFFfafafa),
      ),
      //home: LoginPage(title: 'MyFood Login Page'),
      home: LoginPage(title: "",)
    );
  }
}
